import React, { createContext } from 'react';

export const LocationContext = createContext<GeolocationCoordinates | null>(null);

export const LocationProvider: React.FC<{ value: GeolocationCoordinates | null; children: React.ReactNode }> = ({ value, children }) => {
  return (
    <LocationContext.Provider value={value}>
      {children}
    </LocationContext.Provider>
  );
};