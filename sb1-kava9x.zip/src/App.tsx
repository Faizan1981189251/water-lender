import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Account from './pages/Account';
import WaterLenders from './pages/WaterLenders';
import { LanguageProvider } from './contexts/LanguageContext';
import { LocationProvider } from './contexts/LocationContext';

function App() {
  const [userLocation, setUserLocation] = useState<GeolocationCoordinates | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => setUserLocation(position.coords),
        (error) => console.error('Error getting location:', error)
      );
    }
  }, []);

  return (
    <Router>
      <LanguageProvider>
        <LocationProvider value={userLocation}>
          <div className="flex flex-col min-h-screen">
            <Header />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/account" element={<Account />} />
                <Route path="/water-lenders" element={<WaterLenders />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </LocationProvider>
      </LanguageProvider>
    </Router>
  );
}

export default App;