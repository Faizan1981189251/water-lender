import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { LanguageContext } from '../contexts/LanguageContext';
import { Droplet, User, Globe } from 'lucide-react';

const Header: React.FC = () => {
  const { language, setLanguage } = useContext(LanguageContext);

  return (
    <header className="bg-blue-600 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <Link to="/" className="flex items-center space-x-2">
          <Droplet size={24} />
          <span className="text-xl font-bold">WaterLender</span>
        </Link>
        <nav>
          <ul className="flex space-x-4">
            <li>
              <Link to="/" className="hover:text-blue-200">Home</Link>
            </li>
            <li>
              <Link to="/water-lenders" className="hover:text-blue-200">Water Lenders</Link>
            </li>
            <li>
              <Link to="/account" className="hover:text-blue-200">
                <User size={20} />
              </Link>
            </li>
            <li>
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="bg-blue-500 text-white border border-blue-400 rounded p-1"
              >
                <option value="en">EN</option>
                <option value="es">ES</option>
                <option value="fr">FR</option>
              </select>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  );
};

export default Header;