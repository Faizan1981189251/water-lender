import React from 'react';
import { HelpCircle, MapPin } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white p-4">
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <HelpCircle size={20} />
          <button className="hover:text-blue-300">Help</button>
        </div>
        <div className="flex items-center space-x-2">
          <MapPin size={20} />
          <span>Location Services</span>
        </div>
        <div>© 2024 WaterLender. All rights reserved.</div>
      </div>
    </footer>
  );
};

export default Footer;