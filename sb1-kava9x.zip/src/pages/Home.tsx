import React from 'react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold mb-6">Welcome to WaterLender</h1>
      <p className="text-xl mb-8">Find the best water lenders near you!</p>
      <Link
        to="/water-lenders"
        className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition duration-300"
      >
        Find Water Lenders
      </Link>
    </div>
  );
};

export default Home;