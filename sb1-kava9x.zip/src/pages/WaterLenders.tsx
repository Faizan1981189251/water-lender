import React, { useState, useContext, useEffect } from 'react';
import { LocationContext } from '../contexts/LocationContext';

interface WaterLender {
  id: number;
  name: string;
  distance: number;
  rating: number;
  price: number;
  quality: string;
}

const WaterLenders: React.FC = () => {
  const [lenders, setLenders] = useState<WaterLender[]>([]);
  const [sortBy, setSortBy] = useState<'distance' | 'rating' | 'price'>('distance');
  const userLocation = useContext(LocationContext);

  useEffect(() => {
    // Simulated API call to fetch water lenders
    const fetchLenders = async () => {
      // In a real application, you would make an API call here
      const mockLenders: WaterLender[] = [
        { id: 1, name: "Pure Springs", distance: 1.2, rating: 4.5, price: 2.5, quality: "Excellent" },
        { id: 2, name: "Aqua Solutions", distance: 0.8, rating: 4.2, price: 2.0, quality: "Good" },
        { id: 3, name: "Crystal Clear", distance: 2.5, rating: 4.8, price: 3.0, quality: "Premium" },
        // Add more mock data as needed
      ];
      setLenders(mockLenders);
    };

    fetchLenders();
  }, [userLocation]);

  const sortedLenders = [...lenders].sort((a, b) => {
    if (sortBy === 'distance') return a.distance - b.distance;
    if (sortBy === 'rating') return b.rating - a.rating;
    return a.price - b.price;
  });

  return (
    <div className="container mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold mb-6">Water Lenders Near You</h2>
      <div className="mb-4">
        <label htmlFor="sortBy" className="mr-2">Sort by:</label>
        <select
          id="sortBy"
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value as 'distance' | 'rating' | 'price')}
          className="border rounded p-2"
        >
          <option value="distance">Distance</option>
          <option value="rating">Rating</option>
          <option value="price">Price</option>
        </select>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {sortedLenders.map((lender) => (
          <div key={lender.id} className="border rounded-lg p-4 shadow-md">
            <h3 className="text-xl font-semibold mb-2">{lender.name}</h3>
            <p>Distance: {lender.distance.toFixed(1)} km</p>
            <p>Rating: {lender.rating.toFixed(1)} / 5</p>
            <p>Price: ${lender.price.toFixed(2)} / liter</p>
            <p>Quality: {lender.quality}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default WaterLenders;